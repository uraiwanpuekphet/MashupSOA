<?php

$apikey = "bb78e4cf3442e302d928f2c5edcdbee1";

$sitename = "Update Movie and TV Series ";
$tagline = "Info Film Update";
$email = "hellojuniordev@gmail.com";
$url = "http://juniordev.net";

$imgurl_1 = "http://image.tmdb.org/t/p/w500";
$imgurl_2 = "http://image.tmdb.org/t/p/w300";

?>